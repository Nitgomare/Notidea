'use strict';
// 版本号唯一来源：升级时改这里
module.exports = { version: '1.4.2', name: 'flomo local' };
